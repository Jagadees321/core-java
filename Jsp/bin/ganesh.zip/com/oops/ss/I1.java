package com.oops.ss;

public interface I1 {
     void bikestart();
     void stop();
     
}
