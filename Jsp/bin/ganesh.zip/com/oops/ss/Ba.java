package com.oops.ss;

public class Ba extends Aa {
	@Override
	public int mul(int a,int b) {
		return a*b;
	}

}
