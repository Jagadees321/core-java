package com.oops.ss;

public class A {
	int i;
   void m1(){
	 System.out.println("m1");  
   }


}


class B extends A
{
	int j;
	void m1() {
		System.out.println("m2");
		
	}
	
	
}


