package com.oops.ss;

public abstract class Methods {
    
	int i;
	static int c;
	Methods(){
		
	}
     void m1() {
    	System.out.println("i am m1"); 
     }
    	
    abstract void m2();
  
}
