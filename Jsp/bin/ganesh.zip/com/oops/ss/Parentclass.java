package com.oops.ss;

public class Parentclass {
	
	int a;
	static int b=7;
	






}
