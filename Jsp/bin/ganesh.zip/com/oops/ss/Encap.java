package com.oops.ss;

public class Encap {
     private int i;
     private int j;
     
     
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
     
     
     
}
