package com.oops.ss;

public class Testencap {

	public static void main(String[] args) {
		
		Encap e=new Encap();
		e.setI(9);
		int a=e.getI();
		System.out.println(a);
		

	}

}
