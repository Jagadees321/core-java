package com.oops.ss;

public  class M2 extends Methods{

	@Override
	void m2() {
		System.out.println("i am m2");
		
	}

	

}
