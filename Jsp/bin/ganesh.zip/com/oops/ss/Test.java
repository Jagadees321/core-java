package com.oops.ss;

public class Test {

	public static void main(String[] args) {


       Methods m=new M2();
       m.m1();
       m.m2();


       




	}

}
