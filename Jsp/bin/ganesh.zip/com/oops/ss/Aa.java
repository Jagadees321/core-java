package com.oops.ss;

public class Aa {
	
	
	int mul(int a,int b) {
		return a*b;
	}


}
