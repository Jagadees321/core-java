package com.jsp2;



public class Singleton {
	public static void main(String[] args)  {
		Booktickets.booktickets();
		Booktickets.booktickets();
		Booktickets.booktickets();
		Booktickets.booktickets();
		
		
	}

}
