package com.jsp.Arraylist.linkedlist;

public class Node2 {
	Object e;
	Node2 next;
	Node2 prev;
	public Node2(Object element,Node2 n,Node2 p) {
		e=element;
		next=n;
		prev=p;
	}

}
