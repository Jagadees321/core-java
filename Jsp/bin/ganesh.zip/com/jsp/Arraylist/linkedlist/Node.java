package com.jsp.Arraylist.linkedlist;

public class Node {
	Object e;
    Node next;
	public Node(Object element,Node n) {
		e=element;
		next=n;
	}

}
