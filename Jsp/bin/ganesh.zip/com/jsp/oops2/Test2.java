package com.jsp.oops2;

public class Test2 {
	public static void main(String[] args) {
//	//	C c=new C();
//		System.out.println(c.a);
//		System.out.println(c.b);
		System.out.println("--------------------");
		C c1=new C(4);
		System.out.println(c1.a);
		System.out.println(c1.b);
		
	}

}
