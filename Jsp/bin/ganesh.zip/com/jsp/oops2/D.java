package com.jsp.oops2;

public class D extends C{

	
	int c;
	int k;
	
	public D(int a) {
		super(a);
	}
	public D(int a, int c) {
		this(3);
		this.c = c;
	}
	
	
	
	

}
