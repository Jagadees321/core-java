package com.jsp.oops2;

public class TestG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Interface a=new G();
        a.wakeup();
        a.doyourwork();
        a.sleep();
	}

}
