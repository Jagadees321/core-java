package com.jsp.oops2;

public class R extends O {
	@Override
public O  m1(O b) {
		
		System.out.println("i am m1 in R");
		return b;
	}

}
