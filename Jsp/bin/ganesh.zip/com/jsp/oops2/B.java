package com.jsp.oops2;

public class B extends A{
	int j;
	void m2() {
		System.out.println("i am m2");
	}
	void b1() {
		System.out.println("i am b1 in B class");
	}
	
}
