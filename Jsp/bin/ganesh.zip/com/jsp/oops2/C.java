package com.jsp.oops2;

public class C {
	int a;
	int b;
//	C(){
//		this(6,8);
//		System.out.println("i am default in c con");
//	}
	public C(int a) {
		
		
		this.a = a;
	}
	public C(int a, int b) {
		
		this.a = a;
		this.b = b;
	}
	
	

}
