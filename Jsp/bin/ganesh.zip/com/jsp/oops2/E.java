package com.jsp.oops2;

public class E {
       static void m1() {
    	   System.out.println("i am static in E");
       }
       void m2() {
    	   System.out.println(" i am non static in e");
       }
      
}
