package com.jsp.oops2;

public class Test3 {

	public static void main(String[] args) {
		R r=new R();
		
		System.out.println(r.m1(r));

	}

}
