package com.jsp.oops2;

public class A {
	int i;
	void m1() {
		System.out.println("i am m1");
	}
	void b1() {
		System.out.println("i am b1 in a class");
	}
	

}
