package com.jsp.oops2;

public class O {
	 O  m1(O a) {
		
		System.out.println("i am m1 in O");
		return a;
	}

}
