package com.jsp.oops2;

interface Interface {
	  
      void wakeup();
      void doyourwork();
      void sleep();
}
interface i{
	void m1();
}
