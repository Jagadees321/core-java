package com.jsp.oops2;

public class F  extends E{
	static void m1() {
 	   System.out.println("i am static in f");
    }
	void m2() {
 	   System.out.println(" i am non static in F");
    }
}
