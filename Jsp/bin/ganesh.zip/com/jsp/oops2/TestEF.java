package com.jsp.oops2;

public class TestEF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E.m1();// e class m1
		//E.m2();
        E e=new E();
        
        E.m1();//e class m1
        
        e.m2();//e class
	}

}
