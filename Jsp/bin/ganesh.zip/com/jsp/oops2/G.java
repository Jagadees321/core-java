package com.jsp.oops2;

public class G implements Interface,i
{
	

		@Override
		public void wakeup() {
			// TODO Auto-generated method stub
			System.out.println("wakeup");
		}

		@Override
		public void doyourwork() {
			// TODO Auto-generated method stub
			System.out.println("complete your work");
			
		}

		@Override
		public void sleep() {
			// TODO Auto-generated method stub
			System.out.println("sleep well");
			
		}

		@Override
		public void m1() {
			// TODO Auto-generated method stub
			
		}
		
		
	

}
