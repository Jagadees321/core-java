package com.jsp.oops2;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		A a=new A();
//		//a.m1();
//		a.b1();
//		a.m3();
////		a.m2();//error
//		A a1=new B();//upcastiong
//		a1.b1();//b class m1
//		a1.m3();//a class static
		
		A a=new B();
		a.m1();
		
		
		

	}

}
