package com.jsp.oops2;

public abstract class Aa {
	void m1() {
		System.out.println("i am non static m1 in Aa");
	}
	abstract void m2() ;
		

}
