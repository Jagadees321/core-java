package com.jsp.collections.hashing;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashset h=new Hashset();
		h.add(11);
		h.add(21);
		h.add(32);
		h.add(67);
		h.add(22);
		h.add(53);
		h.size();
		h.display();

	}

}
