package com.jsp.collections.hashing;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        HashsetObj h1=new HashsetObj() ;
        h1.add("hi");
        h1.add(87);
        h1.add("abc");
        h1.add("bca");
        h1.size();
        h1.display();
        
	}

}
