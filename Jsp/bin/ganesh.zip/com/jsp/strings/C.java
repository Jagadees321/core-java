package com.jsp.strings;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="STring".toLowerCase();
		//s1=s1.toLowerCase();
		String s2="strinG".toLowerCase();
		if(s1.equals(s2)) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}

	}

}
