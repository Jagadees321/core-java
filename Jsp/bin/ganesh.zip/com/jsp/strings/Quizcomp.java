package com.jsp.strings;

public class Quizcomp {

	public static void main(String[] args) {
		String a="String";
		String b="string";
		a=a.toLowerCase();
		if(a.equals(b)) {
			System.out.println("true");
		
		}
		else {
			System.out.println("false");
			//
			
		}

	}

}
