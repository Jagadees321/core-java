package com.jsp.strings;

public class Encryption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="bhargav";
		String s2="";
		for(int i=0;i<a.length();i++) {
			char b=a.charAt(i);
			if(b>26) {
				int ch=(b%26)+79+2;
				char s=(char) (ch);
				s2=""+s;
				System.out.println(s2); 
				
				
			}
			
			
			
			
		
			char ch=(char) (b+3);
			s2+=""+ch;
		}
	
		System.out.print(s2);

	}

}
