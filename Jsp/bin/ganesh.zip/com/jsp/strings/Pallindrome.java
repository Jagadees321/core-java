package com.jsp.strings;

public class Pallindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(ispallindrome("mAadam"));

	}
	static boolean ispallindrome(String s) {
		char[]a=s.toCharArray();
		int i=0;int j=s.length()-1;
		while(i<j) {
			if(a[i]!=a[j])return false;
			i++;
			j--;
		}
		return true;
	}

}
