package com.jsp.strings;

public class Immutable {



}
