package com.jsp.Doublelinked;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Double d=new Double();
        d.add(2);
        d.add(5);
        d.add(8);
        d.add(2, 1);
        //d.get1();
        //d.reverse();
        d.forward();
        d.backward();
        
	}

}
