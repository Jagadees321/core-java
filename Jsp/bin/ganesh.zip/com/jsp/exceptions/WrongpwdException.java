package com.jsp.exceptions;

@SuppressWarnings("serial")
public class WrongpwdException extends Exception{

}
