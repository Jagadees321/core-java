package com.jsp.exceptions;

public class Threadsleep {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("hi.....");
		Thread.sleep(1500);
		System.out.println("venky...");
		Thread.sleep(3000);
		System.out.println("how are you?");

	}

}
