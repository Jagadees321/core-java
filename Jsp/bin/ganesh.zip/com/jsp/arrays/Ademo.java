package com.jsp.arrays;

public class Ademo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a=new int[8];

	}

}
