package com.jsp.arrays;

import java.util.Arrays;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a= new int[3];
		
		a[0]=2;
		a[1]=6;
		a[2]=4;
		
		System.out.println(Arrays.toString(a));

	}

}
