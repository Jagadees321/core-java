package com.jsp.oops;

public abstract class M {
      abstract void m1();
}
abstract class Z extends M{

	
	
}
class O extends N{

	@Override
	void m1() {
		// TODO Auto-generated method stub
		
	}
	
}
