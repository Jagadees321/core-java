package com.jsp.oops;

public class Test1 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Bike b=new Bike();
//		b.Start();
//		b=new Duke();
//		b.Start();

	}

}
