package com.jsp.oops;

public class Test8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		N a=new K();//upcasting
		a.m1();
		((K) a).m2();
	}

}
