package com.jsp.oops;

public class Abstraction {
	public static void main(String[] args) {
        Shapes c=new Circle();
		c.draw();
		c.area();
		
	}

}
