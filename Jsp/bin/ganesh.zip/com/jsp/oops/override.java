package com.jsp.oops;

public @interface override {

}
