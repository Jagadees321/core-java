package com.jsp.oops;
interface Shapes{
	void draw();
	void area();
	
}























public class Circle implements Shapes{
	public void draw() {
		System.out.println("draw circle");
	}
	
	
	public void area() {
		// TODO Auto-generated method stub
		System.out.println("area of circle");
		
	}
	
}

