package com.jsp.Queuelist;

public class Node1 {
	Node1 next;
	Object e;
	public Node1(Object e, Node1 next) {
		super();
		this.next =next ;
		this.e = e;
	}
	
	

}
