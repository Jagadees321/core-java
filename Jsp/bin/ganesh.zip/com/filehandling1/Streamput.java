package com.filehandling1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Streamput {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		File f=new File("D:\\jagga jsp\\File\\file5.txt");
		FileOutputStream is=new FileOutputStream(f);
		
	}

}
