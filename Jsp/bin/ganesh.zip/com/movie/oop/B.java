package com.movie.oop;

public class B  implements A{

}
