package com.movie.oop;

public class Singleton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			Booktickets.booktickets();
			Booktickets.booktickets();
			Booktickets.booktickets();
			Booktickets.booktickets();
			
			
		

	}

}
