package com.movie.oop;

interface A {
	
}
