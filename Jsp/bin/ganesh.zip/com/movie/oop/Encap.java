package com.movie.oop;

public class Encap {
	private int i=8;
	private int j=9;
	public int getI(A a) {
		return i;
	}
	public void setI(A b,int i) {
		this.i = i;
	}
	public int getJ() {
		return j;
	}
	public void setJ(int j) {
		this.j = j;
	}
	

}
